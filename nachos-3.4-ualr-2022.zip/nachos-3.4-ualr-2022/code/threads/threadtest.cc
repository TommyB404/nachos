#include "copyright.h"
#include "system.h"

//----------------------------------------------------------------------
// SimpleThread
//----------------------------------------------------------------------
void
SimpleThread(_int which)
{
    const int rounds=3;
    int num;
    for (num = 0; num < 3; num++) {
        printf("*** thread %d looped %d times, priority=%d\n", 
               (int)which, num, currentThread->getPriority());
        if(num<rounds-1){
          currentThread->Yield();}
    }
}

//----------------------------------------------------------------------
// ThreadTest
//----------------------------------------------------------------------
void
ThreadTest()
{
    DEBUG('t', "Entering ThreadTest");

    // Fixed but irregular priorities
    Thread *t3 = new Thread("t3", 8);
    Thread *t1 = new Thread("t1", 6);
    Thread *t4 = new Thread("t4", 4);
    Thread *t2 = new Thread("t2", 2);

    // Fork in irregular order
    t3->Fork(SimpleThread, 3);
    t1->Fork(SimpleThread, 1);
    t4->Fork(SimpleThread, 4);
    t2->Fork(SimpleThread, 2);

    // Main thread yields to let scheduler pick highest priority
    currentThread->Yield();
    
    // Main thread will resume after all child threads finish
    SimpleThread(0);
}
